<?php
/**
 * Админка для плагина Page
 */

class xAdminPage extends xPage
{

    const
        TYPE_TEXT = 'text',
        TYPE_FOTO = 'foto';

    static $fields = array(
        '{{prefix}}_pages' => array(
            'id' => array('type' => 'int', 'IND' => true, 'AUTO' => true),
            'order' => array('type' => 'int'),
            'type' => array('type' => 'str10'),
            'typeid' => array('type' => 'int'),
            'name' => array('type' => 'str80')
        ),
        '{{prefix}}_pages_text' => array(
            'typeid' => array('type' => 'int', 'PRI' => true, 'AUTO' => true),
            'text' => array('type' => 'text'),
            'foto' => array('type' => 'int')
        ),
        '{{prefix}}_pages_foto' => array(
            'id' => array('type' => 'int', 'PRI' => true, 'AUTO' => true),
            'typeid' => array('type' => 'int', 'IND' => true),
            'small' => array('type' => 'str'),
            'swidth' => array('type' => 'int'),
            'sheight' => array('type' => 'int'),
            'big' => array('type' => 'str') ,
            'bwidth' => array('type' => 'int'),
            'bheight' => array('type' => 'int'),
            'name' => array('type' => 'str') ,
            'descr' => array('type' => 'text') ,
            'order' => array('type' => 'int') ,
        ),
    );


    function install($install = true)
    {
        foreach (self::$fields as $table => $fields) {
            $sql = SQL_BUILD::drop($table);
            if ($install) {
                $sql .= SQL_BUILD::create($table, $fields);
            }
            ENGINE::$I->db()->sql_dump($sql);
        }
    }

    function getElement($type, $id)
    {
        return ENGINE::$I->db()->select('select * from {{prefix}}_pages_' . $type
            . ' where `typeid`={{?|int}};', $id);
    }

    function show()
    {
        $current = ENGINE::exec(array('Sitemap', 'current'));
        ENGINE::set_option('page.pageid', $current['id']);
        $page = ENGINE::$I->db()->select(
            'select * from {{prefix}}_pages where `id`={{?|int}} order by `order`;'
            , $current['page']);
        foreach ($page as &$v) {
            $v['data'] = $this->getElement($v['type'], $v['typeid']);
        }
        return ENGINE::$I->template('tpl_admin', '_page', array('data' => $page));
    }

    /**
     * добавить-сменить атрибут у записи
     * Добавить фото, сменить текст
     */
    function do_attr(){
        $type=$_GET['type'];
        switch($type){
            case 'text':
                ENGINE::$I->db()->update('update {{prefix}}_pages_' . $type . ' set text={{?}}',$data);
                break;
            case 'foto':
                ENGINE::$I->db()->update('update {{prefix}}_pages_' . $type . ' set text={{?}}',$data);
                break;
        }

    }

    /**
     * добавить новый инфоблок на страницу в конец списка
     * клик по кнопке без извращений
     * @param $type
     * @return string
     */
    function do_append()
    {
        $sitemap = ENGINE::exec(array('Sitemap', 'getSiteMap'));
        $id = $_POST['id'];
        $type = $_POST['type'];
        if (!in_array($type, array(self::TYPE_TEXT, self::TYPE_FOTO))) {
            ENGINE::error('incorrect TYPE argument');
            return '';
        }
        $current = $sitemap[$id];
        $text_id = ENGINE::$I->db()->insert('insert into {{prefix}}_pages_' . $type . ' set text=""');

        $data = array('typeid' => $text_id, 'type' => $type, 'order' => 1);

        if (empty($current['page'])) {
            $page_id = ENGINE::$I->db()->insert('insert into {{prefix}}_pages ({{?|format("`%s`",",")}}) values ({{?1|values|join(",")}})', $data);
            ENGINE::$I->db()->update('update {{prefix}}_sitemap set `page`={{?|int}} where `id`={{?|int}}', $page_id, $current['id']);
            //        echo '111--'.$page_id;
        } else {
            $page_id = $current['page'];
            $max_order = ENGINE::$I->db()->selectCell(
                'select max(`order`) from {{prefix}}_pages where `id`={{?|int}}'
                , $page_id);

            if (!$max_order) {
                $data['order'] = 1;
                // so no element found!
            } else {
                $data['id'] = $page_id;
                $data['order'] = $max_order + 1;
            }
            ENGINE::$I->db()->insert('insert into {{prefix}}_pages ({{?|format("`%s`",",")}}) values ({{?1|values|join(",")}})', $data);
            //      echo '222--'.$page_id;
        }

        return 'ok';
    }

}